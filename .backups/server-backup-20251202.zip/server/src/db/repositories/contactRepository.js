import { eq, desc, like, and, or, sql, count, lte, gte, isNull } from 'drizzle-orm';
import { db } from '../index';
import { contacts, properties, clientRequests, activities, agents } from '../schema';
export class ContactRepository {
    async create(contact) {
        try {
            const result = await db.insert(contacts).values(contact);
            // Get the inserted ID from the result
            const insertId = Array.isArray(result) && result[0] ? result[0].insertId : result.insertId;
            // console.log('Insert result:', { insertId, result });
            if (insertId) {
                const created = await this.findById(insertId);
                if (created)
                    return created;
                console.log('Failed to find contact by ID:', insertId);
            }
            // Fallback: find by email if no insertId
            if (contact.email) {
                console.log('Trying to find by email:', contact.email);
                const created = await this.findByEmail(contact.email);
                if (created)
                    return created;
            }
            // Fallback: find by phone if no email
            if (contact.phone) {
                console.log('Trying to find by phone:', contact.phone);
                const created = await this.findByPhone(contact.phone);
                if (created)
                    return created;
            }
            // Log the contact data for debugging
            console.log('Contact data that failed to retrieve:', JSON.stringify(contact, null, 2));
            throw new Error(`Failed to retrieve created contact. InsertId: ${insertId}, Email: ${contact.email}, Phone: ${contact.phone}`);
        }
        catch (error) {
            // Provide more detailed error information
            if (error instanceof Error) {
                if (error.message.includes('Duplicate entry')) {
                    throw new Error(`Contact already exists: ${error.message}`);
                }
                if (error.message.includes('cannot be null') || error.message.includes('NOT NULL')) {
                    throw new Error(`Missing required field: ${error.message}`);
                }
                if (error.message.includes('foreign key constraint')) {
                    throw new Error(`Invalid reference: ${error.message}`);
                }
                if (error.message.includes('Failed to retrieve created contact')) {
                    throw error; // Re-throw our custom error with more details
                }
                throw new Error(`Database error: ${error.message}`);
            }
            throw new Error('Failed to create contact');
        }
    }
    async findById(id) {
        const [contact] = await db.select().from(contacts).where(eq(contacts.id, id));
        return contact || null;
    }
    async findByEmail(email) {
        const [contact] = await db.select().from(contacts).where(eq(contacts.email, email));
        return contact || null;
    }
    async findByPhone(phone) {
        const [contact] = await db.select().from(contacts).where(sql `RIGHT(${contacts.phone}, 9) = RIGHT(${phone}, 9)`);
        return contact || null;
    }
    async findByAgency(agencyId) {
        return db.select()
            .from(contacts)
            .where(eq(contacts.agencyId, agencyId))
            .orderBy(desc(contacts.createdAt));
    }
    async findByAgent(agentId) {
        return db.select()
            .from(contacts)
            .where(eq(contacts.assignedAgentId, agentId))
            .orderBy(desc(contacts.createdAt));
    }
    async findByType(contactType, agencyId) {
        const whereClause = agencyId
            ? and(eq(contacts.contactType, contactType), eq(contacts.agencyId, agencyId))
            : eq(contacts.contactType, contactType);
        return db.select()
            .from(contacts)
            .where(whereClause)
            .orderBy(desc(contacts.aiLeadScore), desc(contacts.createdAt));
    }
    async findLeads(agencyId) {
        return db.select()
            .from(contacts)
            .where(and(eq(contacts.agencyId, agencyId), eq(contacts.contactType, 'lead')))
            .orderBy(desc(contacts.aiLeadScore), desc(contacts.createdAt));
    }
    async findHotLeads(agencyId, minScore = 7.0) {
        return db.select()
            .from(contacts)
            .where(and(eq(contacts.agencyId, agencyId), eq(contacts.qualificationStatus, 'hot_lead')))
            .orderBy(desc(contacts.aiLeadScore), desc(contacts.createdAt));
    }
    async search(searchTerm, agencyId) {
        const searchCondition = or(like(contacts.firstName, `%${searchTerm}%`), like(contacts.lastName, `%${searchTerm}%`), like(contacts.email, `%${searchTerm}%`), like(contacts.phone, `%${searchTerm}%`));
        const whereClause = agencyId
            ? and(searchCondition, eq(contacts.agencyId, agencyId))
            : searchCondition;
        return db.select()
            .from(contacts)
            .where(whereClause)
            .orderBy(desc(contacts.createdAt));
    }
    async findAll() {
        return db.select().from(contacts).orderBy(desc(contacts.createdAt));
    }
    async findAllWithCounts() {
        // Calculate cutoff dates for follow-up logic (30 days ago)
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - 30);
        const requestAgeCutoff = cutoffDate.toISOString();
        const activityCutoffDateStr = cutoffDate.toISOString().split('T')[0]; // YYYY-MM-DD format
        const result = await db
            .select({
            id: contacts.id,
            agencyId: contacts.agencyId,
            assignedAgentId: contacts.assignedAgentId,
            firstName: contacts.firstName,
            lastName: contacts.lastName,
            email: contacts.email,
            phone: contacts.phone,
            whatsapp: contacts.whatsapp,
            contactType: contacts.contactType,
            source: contacts.source,
            sourceDetails: contacts.sourceDetails,
            interestedIn: contacts.interestedIn,
            budgetMin: contacts.budgetMin,
            budgetMax: contacts.budgetMax,
            preferredAreas: contacts.preferredAreas,
            propertyPreferences: contacts.propertyPreferences,
            urgencyLevel: contacts.urgencyLevel,
            buyingReadiness: contacts.buyingReadiness,
            preferredContactMethod: contacts.preferredContactMethod,
            bestTimeToCall: contacts.bestTimeToCall,
            communicationNotes: contacts.communicationNotes,
            aiLeadScore: contacts.aiLeadScore,
            qualificationStatus: contacts.qualificationStatus,
            conversionProbability: contacts.conversionProbability,
            lastInteractionScore: contacts.lastInteractionScore,
            lastContactAt: contacts.lastContactAt,
            lastResponseAt: contacts.lastResponseAt,
            nextFollowUpAt: contacts.nextFollowUpAt,
            interactionCount: contacts.interactionCount,
            emailCount: contacts.emailCount,
            callCount: contacts.callCount,
            whatsappCount: contacts.whatsappCount,
            meetingCount: contacts.meetingCount,
            occupation: contacts.occupation,
            company: contacts.company,
            notes: contacts.notes,
            tags: contacts.tags,
            isBlacklisted: contacts.isBlacklisted,
            gdprConsent: contacts.gdprConsent,
            marketingConsent: contacts.marketingConsent,
            createdAt: contacts.createdAt,
            updatedAt: contacts.updatedAt,
            propertiesCount: sql `COALESCE(${sql `p.property_count`}, 0)`.as('propertiesCount'),
            clientRequestsCount: sql `COALESCE(${sql `cr.request_count`}, 0)`.as('clientRequestsCount'),
            needFollowUp: sql `CASE WHEN COALESCE(${sql `fu.has_followup_needed`}, 0) > 0 THEN 1 ELSE 0 END`.as('needFollowUp'),
            assignedAgentName: agents.firstName
        })
            .from(contacts)
            .leftJoin(agents, eq(contacts.assignedAgentId, agents.id))
            .leftJoin(sql `(SELECT owner_contact_id, COUNT(*) as property_count FROM properties WHERE owner_contact_id IS NOT NULL GROUP BY owner_contact_id) p`, sql `p.owner_contact_id = ${contacts.id}`)
            .leftJoin(sql `(SELECT contact_id, COUNT(*) as request_count FROM client_requests GROUP BY contact_id) cr`, sql `cr.contact_id = ${contacts.id}`)
            .leftJoin(sql `(
          SELECT 
            contact_id, 
            COUNT(*) as has_followup_needed
          FROM client_requests cr_fu
          WHERE 
            cr_fu.status IN ('nou', 'in_procesare')
            AND cr_fu.created_at <= ${requestAgeCutoff}
            AND NOT EXISTS (
              SELECT 1 FROM activities a 
              WHERE a.request_id = cr_fu.id 
              AND STR_TO_DATE(a.scheduled_date, '%d-%m-%Y') >= ${activityCutoffDateStr}
            )
          GROUP BY contact_id
        ) fu`, sql `fu.contact_id = ${contacts.id}`)
            .orderBy(desc(contacts.createdAt));
        return result;
    }
    async findAllPaginated(limit = 15, offset = 0) {
        // Get total count
        const countResults = await db.select({ count: sql `count(*)` }).from(contacts);
        const total = countResults[0]?.count || 0;
        // Get paginated data
        const data = await db
            .select()
            .from(contacts)
            .orderBy(desc(contacts.createdAt))
            .limit(limit)
            .offset(offset);
        return { data, total };
    }
    async findAllPaginatedWithCounts(limit = 15, offset = 0) {
        // Get total count
        const countResults = await db.select({ count: sql `count(*)` }).from(contacts);
        const total = countResults[0]?.count || 0;
        // Calculate cutoff dates for follow-up logic (30 days ago)
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - 30);
        const requestAgeCutoff = cutoffDate.toISOString();
        const activityCutoffDateStr = cutoffDate.toISOString().split('T')[0]; // YYYY-MM-DD format
        // Get paginated data with counts
        const data = await db
            .select({
            id: contacts.id,
            agencyId: contacts.agencyId,
            assignedAgentId: contacts.assignedAgentId,
            firstName: contacts.firstName,
            lastName: contacts.lastName,
            email: contacts.email,
            phone: contacts.phone,
            whatsapp: contacts.whatsapp,
            contactType: contacts.contactType,
            source: contacts.source,
            sourceDetails: contacts.sourceDetails,
            interestedIn: contacts.interestedIn,
            budgetMin: contacts.budgetMin,
            budgetMax: contacts.budgetMax,
            preferredAreas: contacts.preferredAreas,
            propertyPreferences: contacts.propertyPreferences,
            urgencyLevel: contacts.urgencyLevel,
            buyingReadiness: contacts.buyingReadiness,
            preferredContactMethod: contacts.preferredContactMethod,
            bestTimeToCall: contacts.bestTimeToCall,
            communicationNotes: contacts.communicationNotes,
            aiLeadScore: contacts.aiLeadScore,
            qualificationStatus: contacts.qualificationStatus,
            conversionProbability: contacts.conversionProbability,
            lastInteractionScore: contacts.lastInteractionScore,
            lastContactAt: contacts.lastContactAt,
            lastResponseAt: contacts.lastResponseAt,
            nextFollowUpAt: contacts.nextFollowUpAt,
            interactionCount: contacts.interactionCount,
            emailCount: contacts.emailCount,
            callCount: contacts.callCount,
            whatsappCount: contacts.whatsappCount,
            meetingCount: contacts.meetingCount,
            occupation: contacts.occupation,
            company: contacts.company,
            notes: contacts.notes,
            tags: contacts.tags,
            isBlacklisted: contacts.isBlacklisted,
            gdprConsent: contacts.gdprConsent,
            marketingConsent: contacts.marketingConsent,
            createdAt: contacts.createdAt,
            updatedAt: contacts.updatedAt,
            propertiesCount: sql `COALESCE(${sql `p.property_count`}, 0)`.as('propertiesCount'),
            clientRequestsCount: sql `COALESCE(${sql `cr.request_count`}, 0)`.as('clientRequestsCount'),
            needFollowUp: sql `CASE WHEN COALESCE(${sql `fu.has_followup_needed`}, 0) > 0 THEN 1 ELSE 0 END`.as('needFollowUp'),
            assignedAgentName: agents.firstName
        })
            .from(contacts)
            .leftJoin(agents, eq(contacts.assignedAgentId, agents.id))
            .leftJoin(sql `(SELECT owner_contact_id, COUNT(*) as property_count FROM properties WHERE owner_contact_id IS NOT NULL GROUP BY owner_contact_id) p`, sql `p.owner_contact_id = ${contacts.id}`)
            .leftJoin(sql `(SELECT contact_id, COUNT(*) as request_count FROM client_requests GROUP BY contact_id) cr`, sql `cr.contact_id = ${contacts.id}`)
            .leftJoin(sql `(
          SELECT 
            contact_id, 
            COUNT(*) as has_followup_needed
          FROM client_requests cr_fu
          WHERE 
            cr_fu.status IN ('nou', 'in_procesare')
            AND cr_fu.created_at <= ${requestAgeCutoff}
            AND NOT EXISTS (
              SELECT 1 FROM activities a 
              WHERE a.request_id = cr_fu.id 
              AND STR_TO_DATE(a.scheduled_date, '%d-%m-%Y') >= ${activityCutoffDateStr}
            )
          GROUP BY contact_id
        ) fu`, sql `fu.contact_id = ${contacts.id}`)
            .orderBy(desc(contacts.createdAt))
            .limit(limit)
            .offset(offset);
        return {
            data: data,
            total
        };
    }
    async update(id, updates) {
        await db.update(contacts).set(updates).where(eq(contacts.id, id));
        return this.findById(id);
    }
    async updateLeadScore(id, score) {
        return this.update(id, { aiLeadScore: score.toString() });
    }
    async assignToAgent(id, agentId) {
        return this.update(id, { assignedAgentId: agentId });
    }
    async updateQualification(id, status) {
        return this.update(id, { qualificationStatus: status });
    }
    async recordInteraction(id, type) {
        const contact = await this.findById(id);
        if (!contact)
            return null;
        const updates = {
            lastContactAt: new Date().toISOString(),
            interactionCount: (contact.interactionCount || 0) + 1,
        };
        // Update specific interaction counters
        switch (type) {
            case 'email':
                updates.emailCount = (contact.emailCount || 0) + 1;
                break;
            case 'call':
                updates.callCount = (contact.callCount || 0) + 1;
                break;
            case 'whatsapp':
                updates.whatsappCount = (contact.whatsappCount || 0) + 1;
                break;
            case 'meeting':
                updates.meetingCount = (contact.meetingCount || 0) + 1;
                break;
        }
        return this.update(id, updates);
    }
    async blacklist(id) {
        return this.update(id, { isBlacklisted: true });
    }
    async unblacklist(id) {
        return this.update(id, { isBlacklisted: false });
    }
    async delete(id) {
        const result = await db.delete(contacts).where(eq(contacts.id, id));
        return result.affectedRows > 0;
    }
    async findFullContext(contactId) {
        // Get the contact details with assigned agent info
        const contactResult = await db
            .select({
            id: contacts.id,
            agencyId: contacts.agencyId,
            assignedAgentId: contacts.assignedAgentId,
            firstName: contacts.firstName,
            lastName: contacts.lastName,
            email: contacts.email,
            phone: contacts.phone,
            whatsapp: contacts.whatsapp,
            contactType: contacts.contactType,
            source: contacts.source,
            sourceDetails: contacts.sourceDetails,
            interestedIn: contacts.interestedIn,
            budgetMin: contacts.budgetMin,
            budgetMax: contacts.budgetMax,
            preferredAreas: contacts.preferredAreas,
            propertyPreferences: contacts.propertyPreferences,
            urgencyLevel: contacts.urgencyLevel,
            buyingReadiness: contacts.buyingReadiness,
            preferredContactMethod: contacts.preferredContactMethod,
            bestTimeToCall: contacts.bestTimeToCall,
            communicationNotes: contacts.communicationNotes,
            aiLeadScore: contacts.aiLeadScore,
            qualificationStatus: contacts.qualificationStatus,
            conversionProbability: contacts.conversionProbability,
            lastInteractionScore: contacts.lastInteractionScore,
            lastContactAt: contacts.lastContactAt,
            lastResponseAt: contacts.lastResponseAt,
            nextFollowUpAt: contacts.nextFollowUpAt,
            interactionCount: contacts.interactionCount,
            emailCount: contacts.emailCount,
            callCount: contacts.callCount,
            whatsappCount: contacts.whatsappCount,
            meetingCount: contacts.meetingCount,
            occupation: contacts.occupation,
            company: contacts.company,
            notes: contacts.notes,
            tags: contacts.tags,
            isBlacklisted: contacts.isBlacklisted,
            gdprConsent: contacts.gdprConsent,
            marketingConsent: contacts.marketingConsent,
            createdAt: contacts.createdAt,
            updatedAt: contacts.updatedAt,
            assignedAgentName: agents.firstName,
            assignedAgentPhone: agents.phone
        })
            .from(contacts)
            .leftJoin(agents, eq(contacts.assignedAgentId, agents.id))
            .where(eq(contacts.id, contactId))
            .limit(1);
        const contact = contactResult.length > 0 ? {
            ...contactResult[0],
            assignedAgentName: (contactResult[0]?.assignedAgentName) ?? undefined,
            assignedAgentPhone: (contactResult[0]?.assignedAgentPhone) ?? undefined
        } : null;
        if (!contact) {
            return {
                contact: null,
                ownedProperty: null,
                clientRequest: null,
                activities: []
            };
        }
        // Get property where contact is the owner
        const ownedPropertyResult = await db
            .select({
            id: properties.id,
            internalCode: properties.internalCode,
            title: properties.title,
            description: properties.description,
            propertyType: properties.propertyType,
            transactionType: properties.transactionType,
            price: properties.price,
            currency: properties.currency,
            city: properties.city,
            neighborhood: properties.neighborhood,
            status: properties.status,
            photos: properties.photos,
            virtualTourUrl: properties.virtualTourUrl,
            availableFrom: properties.availableFrom,
            surfaceArea: properties.surfaceArea,
            rooms: properties.rooms,
            bedrooms: properties.bedrooms,
            bathrooms: properties.bathrooms,
            floor: properties.floor,
            constructionYear: properties.constructionYear,
            createdAt: properties.createdAt
        })
            .from(properties)
            .where(eq(properties.ownerContactId, contactId))
            .limit(1);
        const ownedProperty = ownedPropertyResult.length > 0 ? ownedPropertyResult[0] : null;
        // Get client request for this contact (most recent one) with related property info
        const clientRequestResult = await db
            .select({
            id: clientRequests.id,
            title: clientRequests.title,
            description: clientRequests.description,
            requestType: clientRequests.requestType,
            status: clientRequests.status,
            propertyType: clientRequests.propertyType,
            budgetMin: clientRequests.budgetMin,
            budgetMax: clientRequests.budgetMax,
            priority: clientRequests.priority,
            urgencyLevel: clientRequests.urgencyLevel,
            preferredLocations: clientRequests.preferredLocations,
            minRooms: clientRequests.minRooms,
            maxRooms: clientRequests.maxRooms,
            minSurface: clientRequests.minSurface,
            maxSurface: clientRequests.maxSurface,
            createdAt: clientRequests.createdAt,
            nextFollowUpAt: clientRequests.nextFollowUpAt,
            propertyId: clientRequests.propertyId,
            // Get property internal code and virtual tour URL if there's a related property
            propertyInternalCode: properties.internalCode,
            virtualTourUrl: properties.virtualTourUrl,
            sourcePropertyDescription: properties.features
        })
            .from(clientRequests)
            .leftJoin(properties, eq(clientRequests.propertyId, properties.id))
            .where(eq(clientRequests.contactId, contactId))
            .orderBy(desc(clientRequests.createdAt))
            .limit(1);
        const clientRequest = clientRequestResult.length > 0 ? clientRequestResult[0] : null;
        // Get all activities related to this contact
        const activitiesResult = await db
            .select({
            id: activities.id,
            name: activities.name,
            memo: activities.memo,
            activityType: activities.activityType,
            status: activities.status,
            scheduledDate: activities.scheduledDate,
            scheduledTime: activities.scheduledTime,
            scheduledDateTime: activities.scheduledDateTime,
            agentName: activities.agentName,
            propertyCode: activities.propertyCode,
            requestCode: activities.requestCode,
            createdAt: activities.createdAt,
            completedAt: activities.completedAt
        })
            .from(activities)
            .where(eq(activities.contactId, contactId))
            .orderBy(desc(activities.scheduledDateTime), desc(activities.createdAt));
        return {
            contact,
            ownedProperty,
            clientRequest,
            activities: activitiesResult
        };
    }
}
