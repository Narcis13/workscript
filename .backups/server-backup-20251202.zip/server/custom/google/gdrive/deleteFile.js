var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Node, NodeMetadata, SimpleEdgeMap } from '../../../../core/types/node';
import { ExecutionContext } from '../../../../core/types/context';
import { RegisterNode } from '../../../registry';
import { google } from 'googleapis';
let DeleteFileNode = class DeleteFileNode {
    metadata = {
        name: 'deleteFile',
        description: 'Deletes a file or folder from Google Drive',
        type: 'action',
        ai_hints: {
            purpose: 'Delete a file or folder from Google Drive',
            when_to_use: 'When you need to permanently delete a file or folder',
            expected_edges: ['success', 'error', 'not_found', 'config_error'],
            example_usage: 'Delete file or folder by ID'
        }
    };
    async execute(context) {
        const { config, state } = context;
        const accessToken = state.get("google_token");
        try {
            if (!accessToken) {
                return { config_error: () => ({ error: "No Google access token found. Please connect to Google first." }) };
            }
            if (!config?.fileId) {
                return { config_error: () => ({ error: "File ID is required" }) };
            }
            const oauth2Client = new google.auth.OAuth2();
            oauth2Client.setCredentials({ access_token: accessToken });
            const drive = google.drive({ version: 'v3', auth: oauth2Client });
            // Get file metadata first to check if it exists
            let fileMetadata;
            try {
                const metadataResponse = await drive.files.get({
                    fileId: config.fileId,
                    fields: 'id, name, mimeType'
                });
                fileMetadata = metadataResponse.data;
            }
            catch (error) {
                if (error.code === 404) {
                    return { not_found: () => ({ fileId: config.fileId }) };
                }
                throw error;
            }
            // Delete the file
            await drive.files.delete({
                fileId: config.fileId
            });
            const resultPayload = {
                fileId: config.fileId,
                fileName: fileMetadata.name,
                mimeType: fileMetadata.mimeType,
                deletedAt: new Date().toISOString(),
                wasFolder: fileMetadata.mimeType === 'application/vnd.google-apps.folder'
            };
            state.set('lastFileDeleted', resultPayload);
            return { success: () => resultPayload };
        }
        catch (error) {
            console.error('Error in deleteFile:', error);
            if (error.code === 404) {
                return { not_found: () => ({ fileId: config?.fileId }) };
            }
            return {
                error: () => ({
                    message: 'Failed to delete file from Google Drive',
                    details: error instanceof Error ? error.message : String(error)
                })
            };
        }
    }
};
DeleteFileNode = __decorate([
    RegisterNode
], DeleteFileNode);
export { DeleteFileNode };
export const deleteFile = new DeleteFileNode();
